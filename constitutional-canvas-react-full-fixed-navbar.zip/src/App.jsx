import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar.jsx";
import Footer from "./components/Footer.jsx";

import Index from "./pages/Index.jsx";
import PortfolioCivil from "./pages/PortfolioCivil.jsx";
import PortfolioCriminal from "./pages/PortfolioCriminal.jsx";
import PortfolioConstitutional from "./pages/PortfolioConstitutional.jsx";
import PortfolioCorporate from "./pages/PortfolioCorporate.jsx";
import PortfolioPublicInterest from "./pages/PortfolioPublicInterest.jsx";
import AllCases from "./pages/AllCases.jsx";

function App() {
  return (
    <div>
      <Navbar />
      <Routes>
        <Route path="/" element={<Index />} />
        <Route path="/portfolio-civil" element={<PortfolioCivil />} />
        <Route path="/portfolio-criminal" element={<PortfolioCriminal />} />
        <Route path="/portfolio-constitutional" element={<PortfolioConstitutional />} />
        <Route path="/portfolio-corporate" element={<PortfolioCorporate />} />
        <Route path="/portfolio-public-interest" element={<PortfolioPublicInterest />} />
        <Route path="/all-cases" element={<AllCases />} />
      </Routes>
      <Footer />
    </div>
  );
}

export default App;
