import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <nav className="navbar">
      <div className="nav-content">
        <Link to="/" className="logo">
          <span className="sanskrit-text">न्यायालय</span>
          <span className="logo-english">Constitutional Canvas</span>
        </Link>
        <ul className="nav-menu">
          <li className="nav-item"><a href="#home" className="nav-link">Home</a></li>
          <li className="nav-item"><a href="#about" className="nav-link">About</a></li>
          <li className="nav-item dropdown">
            <span className="nav-link">Practice Areas <span className="dropdown-arrow">▼</span></span>
            <ul className="dropdown-menu">
              <li><Link to="/portfolio-criminal">⚖️ Criminal Defense</Link></li>
              <li><Link to="/portfolio-civil">📜 Civil Litigation</Link></li>
              <li><Link to="/portfolio-corporate">🏢 Corporate Law</Link></li>
              <li><Link to="/portfolio-public-interest">🌟 Public Interest</Link></li>
              <li><Link to="/portfolio-constitutional">📘 Constitutional Law</Link></li>
            </ul>
          </li>
          <li className="nav-item dropdown">
            <span className="nav-link">Cases <span className="dropdown-arrow">▼</span></span>
            <ul className="dropdown-menu">
              <li><Link to="/all-cases">📚 All Cases</Link></li>
            </ul>
          </li>
          <li className="nav-item"><a href="#contact" className="nav-link">Contact</a></li>
        </ul>
        <div className="nav-mobile-toggle" id="nav-mobile-toggle">
          <span></span><span></span><span></span>
        </div>
        <div className="legal-emblem"><div className="emblem-circle">⚖️</div></div>
      </div>
    </nav>
  );
}
