import React from 'react';

export default function Footer() {
  return (
    <div className="legacy-page">
      <footer className="footer">
          <div className="footer-content">
              <div className="footer-top">
                  <div className="footer-logo">
                      <h3 className="logo-text">
                          <span className="sanskrit-text">न्यायाधीश</span>
                          <span className="english-text">Constitutional Canvas</span>
                      </h3>
                      <div className="footer-seal">
                          <div className="seal-symbol">⚖️</div>
                      </div>
                  </div>
            
                  <div className="footer-quote">
                      <blockquote>
                          "साक्षिणो हि यथा साक्ष्ये तत्त्वं ब्रूयुर्न चान्यथा"<br />
                          <em>"Witnesses should speak the truth in testimony, and not otherwise"</em>
                      </blockquote>
                  </div>
              </div>
        
              <div className="footer-divider"></div>
        
              <div className="footer-bottom">
                  <div className="footer-info">
                      <p>&copy; 2025 Constitutional Canvas. All rights reserved.</p>
                      <p>Registered with Bar Council of India | License No: D/1234/2025</p>
                  </div>
            
                  <div className="footer-disclaimer">
                      <p><strong>Disclaimer:</strong> This website is for informational purposes only and does not constitute legal advice. 
                      Consultation with a qualified attorney is recommended for specific legal matters.</p>
                  </div>
              </div>
          </div>
      </footer>

      
    </div>
  )
}
