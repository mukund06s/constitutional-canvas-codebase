import React from 'react';

export default function PortfolioCivil() {
  return (
    <div className="legacy-page">
      <div id="scroll-progress"></div>
          <div id="navbar-container"></div>
    
          <section className="portfolio-hero illuminated-border">
              <div className="container">
                  <div className="hero-content">
                      <div className="drop-cap">C</div>
                      <h1 className="hero-title">
                          <span className="sanskrit-text">नागरिक वाद</span>
                          <span className="english-text">Civil Litigation</span>
                      </h1>
                      <p className="hero-subtitle">Resolving Disputes Through Legal Excellence and Strategic Advocacy</p>
                      <div className="constitution-quote scroll-highlight" data-highlight="true">
                          <blockquote>
                              "सर्वे भवन्तु सुखिनः सर्वे सन्तु निरामयाः"<br />
                              <em>"May all be happy, may all be free from disputes"</em>
                          </blockquote>
                      </div>
                  </div>
              </div>
          </section>

          <section className="litigation-areas illuminated-border">
              <div className="container">
                  <div className="section-header">
                      <div className="drop-cap">S</div>
                      <h2 className="section-title">
                          <span className="sanskrit-text">विशेषीकरण</span>
                          <span className="english-text">Specialization Areas</span>
                      </h2>
                  </div>
            
                  <div className="areas-showcase">
                      <div className="area-card featured">
                          <div className="card-header">
                              <h3>Property & Real Estate</h3>
                              <div className="stamp-seal">🏘️</div>
                          </div>
                          <ul className="area-details">
                              <li>Property title disputes</li>
                              <li>Real estate transactions</li>
                              <li>Land acquisition challenges</li>
                              <li>Construction contract disputes</li>
                              <li>Landlord-tenant matters</li>
                          </ul>
                          <div className="success-rate">
                              <span className="rate">92%</span>
                              <span className="label">Success Rate</span>
                          </div>
                      </div>
                
                      <div className="area-card">
                          <div className="card-header">
                              <h3>Contract Disputes</h3>
                              <div className="stamp-seal">📋</div>
                          </div>
                          <ul className="area-details">
                              <li>Breach of contract claims</li>
                              <li>Commercial agreements</li>
                              <li>Service contract disputes</li>
                              <li>Employment contracts</li>
                              <li>International contracts</li>
                          </ul>
                          <div className="success-rate">
                              <span className="rate">89%</span>
                              <span className="label">Success Rate</span>
                          </div>
                      </div>
                
                      <div className="area-card">
                          <div className="card-header">
                              <h3>Personal Injury</h3>
                              <div className="stamp-seal">🩹</div>
                          </div>
                          <ul className="area-details">
                              <li>Motor accident claims</li>
                              <li>Medical negligence</li>
                              <li>Workplace injuries</li>
                              <li>Product liability</li>
                              <li>Insurance disputes</li>
                          </ul>
                          <div className="success-rate">
                              <span className="rate">94%</span>
                              <span className="label">Success Rate</span>
                          </div>
                      </div>
                
                      <div className="area-card">
                          <div className="card-header">
                              <h3>Family & Matrimonial</h3>
                              <div className="stamp-seal">👨‍👩‍👧‍👦</div>
                          </div>
                          <ul className="area-details">
                              <li>Divorce proceedings</li>
                              <li>Child custody matters</li>
                              <li>Alimony and maintenance</li>
                              <li>Property settlements</li>
                              <li>Adoption procedures</li>
                          </ul>
                          <div className="success-rate">
                              <span className="rate">87%</span>
                              <span className="label">Success Rate</span>
                          </div>
                      </div>
                  </div>
              </div>
          </section>

          <section className="major-cases illuminated-border">
              <div className="container">
                  <div className="section-header">
                      <div className="drop-cap">M</div>
                      <h2 className="section-title">
                          <span className="sanskrit-text">महत्वपूर्ण मुकदमे</span>
                          <span className="english-text">Major Civil Cases</span>
                      </h2>
                  </div>
            
                  <div className="cases-grid">
                      <div className="major-case-card">
                          <div className="case-header">
                              <h3>Landmark Property Rights Case</h3>
                              <span className="case-value">₹250 Crores</span>
                          </div>
                          <div className="case-description">
                              <p>Successfully represented a consortium of property owners in a complex land acquisition dispute against state authorities. Established important precedents for fair compensation and rehabilitation.</p>
                          </div>
                          <div className="case-details">
                              <span className="court">Delhi High Court</span>
                              <span className="duration">36 months</span>
                              <span className="outcome victory">Victory</span>
                          </div>
                      </div>
                
                      <div className="major-case-card">
                          <div className="case-header">
                              <h3>International Contract Dispute</h3>
                              <span className="case-value">₹180 Crores</span>
                          </div>
                          <div className="case-description">
                              <p>Multi-jurisdictional contract dispute involving Indian and Singapore entities. Successfully enforced arbitration award and established cross-border enforcement mechanisms.</p>
                          </div>
                          <div className="case-details">
                              <span className="court">Supreme Court</span>
                              <span className="duration">42 months</span>
                              <span className="outcome victory">Victory</span>
                          </div>
                      </div>
                
                      <div className="major-case-card">
                          <div className="case-header">
                              <h3>Medical Negligence Class Action</h3>
                              <span className="case-value">₹75 Crores</span>
                          </div>
                          <div className="case-description">
                              <p>Represented multiple families in a medical negligence class action against a leading hospital chain. Secured substantial compensation and policy changes.</p>
                          </div>
                          <div className="case-details">
                              <span className="court">Bombay High Court</span>
                              <span className="duration">28 months</span>
                              <span className="outcome settled">Settlement</span>
                          </div>
                      </div>
                  </div>
              </div>
          </section>

          <section className="approach-section illuminated-border">
              <div className="container">
                  <div className="section-header">
                      <div className="drop-cap">O</div>
                      <h2 className="section-title">
                          <span className="sanskrit-text">हमारा दृष्टिकोण</span>
                          <span className="english-text">Our Approach</span>
                      </h2>
                  </div>
            
                  <div className="approach-timeline">
                      <div className="timeline-item">
                          <div className="timeline-number">01</div>
                          <div className="timeline-content">
                              <h4>Case Analysis</h4>
                              <p>Comprehensive review of facts, legal precedents, and strategic options</p>
                          </div>
                      </div>
                
                      <div className="timeline-item">
                          <div className="timeline-number">02</div>
                          <div className="timeline-content">
                              <h4>Strategy Development</h4>
                              <p>Crafting tailored legal strategies based on case specifics and client objectives</p>
                          </div>
                      </div>
                
                      <div className="timeline-item">
                          <div className="timeline-number">03</div>
                          <div className="timeline-content">
                              <h4>Evidence Building</h4>
                              <p>Meticulous evidence collection and expert witness coordination</p>
                          </div>
                      </div>
                
                      <div className="timeline-item">
                          <div className="timeline-number">04</div>
                          <div className="timeline-content">
                              <h4>Negotiation & Trial</h4>
                              <p>Strategic negotiations and vigorous courtroom advocacy when required</p>
                          </div>
                      </div>
                  </div>
              </div>
          </section>

          <div id="footer-container"></div>
    </div>
  )
}
