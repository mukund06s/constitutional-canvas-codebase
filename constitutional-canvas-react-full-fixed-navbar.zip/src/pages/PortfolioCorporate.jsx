import React from 'react';

export default function PortfolioCorporate() {
  return (
    <div className="legacy-page">
      <div id="scroll-progress"></div>
          <div id="navbar-container"></div>
    
          <section className="portfolio-hero illuminated-border">
              <div className="container">
                  <div className="hero-content">
                      <div className="drop-cap">C</div>
                      <h1 className="hero-title">
                          <span className="sanskrit-text">निगम विधि</span>
                          <span className="english-text">Corporate Law</span>
                      </h1>
                      <p className="hero-subtitle">Navigating Business Complexities with Legal Precision</p>
                      <div className="hero-nav">
                          <a href="/index" className="breadcrumb">Home</a>
                          <span className="breadcrumb-sep">›</span>
                          <span className="breadcrumb current">Corporate Law</span>
                      </div>
                  </div>
              </div>
          </section>

          <section className="corporate-expertise illuminated-border">
              <div className="container">
                  <div className="section-header">
                      <div className="drop-cap">E</div>
                      <h2 className="section-title">
                          <span className="sanskrit-text">विशेषज्ञता</span>
                          <span className="english-text">Corporate Expertise</span>
                      </h2>
                  </div>
            
                  <div className="expertise-showcase">
                      <div className="expertise-main">
                          <h3>Comprehensive Corporate Legal Services</h3>
                          <p>Our corporate law practice encompasses the full spectrum of business legal needs, from startup formation to complex mergers and acquisitions, ensuring your business operates within the legal framework while maximizing opportunities for growth.</p>
                      </div>
                
                      <div className="expertise-areas">
                          <div className="area-item">
                              <div className="area-icon">🏛️</div>
                              <h4>Corporate Governance</h4>
                              <p>Board compliance, regulatory adherence, and governance framework development</p>
                          </div>
                    
                          <div className="area-item">
                              <div className="area-icon">🤝</div>
                              <h4>Mergers & Acquisitions</h4>
                              <p>Strategic transactions, due diligence, and regulatory approvals</p>
                          </div>
                    
                          <div className="area-item">
                              <div className="area-icon">📊</div>
                              <h4>Securities & Capital Markets</h4>
                              <p>IPOs, private placements, and SEBI compliance</p>
                          </div>
                    
                          <div className="area-item">
                              <div className="area-icon">⚖️</div>
                              <h4>Corporate Litigation</h4>
                              <p>Shareholder disputes, commercial litigation, and arbitration</p>
                          </div>
                    
                          <div className="area-item">
                              <div className="area-icon">🛡️</div>
                              <h4>Compliance & Risk</h4>
                              <p>Regulatory compliance, risk assessment, and internal investigations</p>
                          </div>
                    
                          <div className="area-item">
                              <div className="area-icon">🌐</div>
                              <h4>International Business</h4>
                              <p>Cross-border transactions, foreign investment, and international contracts</p>
                          </div>
                      </div>
                  </div>
              </div>
          </section>

          <div id="footer-container"></div>
    </div>
  )
}
