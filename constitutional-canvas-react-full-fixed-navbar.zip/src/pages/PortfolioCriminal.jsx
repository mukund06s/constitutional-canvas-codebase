import React from 'react';

export default function PortfolioCriminal() {
  return (
    <div className="legacy-page">
      <div id="scroll-progress"></div>
          <div id="navbar-container"></div>
    
          <section className="portfolio-hero illuminated-border">
              <div className="container">
                  <div className="hero-content">
                      <div className="drop-cap">C</div>
                      <h1 className="hero-title">
                          <span className="sanskrit-text">अपराध रक्षा</span>
                          <span className="english-text">Criminal Defense</span>
                      </h1>
                      <p className="hero-subtitle">Protecting Rights, Ensuring Justice, Upholding Due Process</p>
                      <div className="constitution-quote scroll-highlight" data-highlight="true">
                          <blockquote>
                              "No person shall be deprived of his life or personal liberty except according to procedure established by law." 
                              - Article 21, Indian Constitution
                          </blockquote>
                      </div>
                  </div>
              </div>
          </section>

          <section className="expertise-section illuminated-border">
              <div className="container">
                  <div className="section-header">
                      <div className="drop-cap">E</div>
                      <h2 className="section-title">
                          <span className="sanskrit-text">विशेषज्ञता</span>
                          <span className="english-text">Areas of Expertise</span>
                      </h2>
                  </div>
            
                  <div className="expertise-grid">
                      <div className="expertise-card">
                          <div className="card-icon">🛡️</div>
                          <h3>White Collar Crimes</h3>
                          <p>Financial fraud, corruption, money laundering, and regulatory violations</p>
                      </div>
                
                      <div className="expertise-card">
                          <div className="card-icon">⚖️</div>
                          <h3>High Court Appeals</h3>
                          <p>Complex criminal appeals and constitutional challenges</p>
                      </div>
                
                      <div className="expertise-card">
                          <div className="card-icon">🔍</div>
                          <h3>Investigation Defense</h3>
                          <p>Pre-charge representation and investigation oversight</p>
                      </div>
                
                      <div className="expertise-card">
                          <div className="card-icon">📋</div>
                          <h3>Bail Applications</h3>
                          <p>Securing bail in complex and high-profile cases</p>
                      </div>
                  </div>
              </div>
          </section>

          <section className="case-studies illuminated-border">
              <div className="container">
                  <div className="section-header">
                      <div className="drop-cap">N</div>
                      <h2 className="section-title">
                          <span className="sanskrit-text">उल्लेखनीय मामले</span>
                          <span className="english-text">Notable Defense Cases</span>
                      </h2>
                  </div>
            
                  <div className="case-timeline">
                      <div className="case-item">
                          <div className="case-year">2024</div>
                          <div className="case-details">
                              <h3>State vs. Corporate Executive - Financial Fraud</h3>
                              <p>Successfully defended a multinational corporation executive against charges of financial irregularities worth ₹500 crores. Established precedent for corporate liability limitations.</p>
                              <div className="case-stats">
                                  <span className="stat">Duration: 18 months</span>
                                  <span className="stat">Court: Delhi High Court</span>
                              </div>
                              <div className="case-outcome victory">Acquittal</div>
                          </div>
                      </div>
                
                      <div className="case-item">
                          <div className="case-year">2023</div>
                          <div className="case-details">
                              <h3>Anti-Corruption Bureau vs. Public Official</h3>
                              <p>Defended senior government official in high-profile corruption case. Challenged evidence collection procedures and secured constitutional protection.</p>
                              <div className="case-stats">
                                  <span className="stat">Duration: 24 months</span>
                                  <span className="stat">Court: Supreme Court</span>
                              </div>
                              <div className="case-outcome victory">Charges Dropped</div>
                          </div>
                      </div>
                
                      <div className="case-item">
                          <div className="case-year">2022</div>
                          <div className="case-details">
                              <h3>CBI vs. Banking Consortium - Money Laundering</h3>
                              <p>Complex money laundering case involving international transactions. Successfully argued for jurisdictional challenges and procedural violations.</p>
                              <div className="case-stats">
                                  <span className="stat">Duration: 30 months</span>
                                  <span className="stat">Court: Bombay High Court</span>
                              </div>
                              <div className="case-outcome settled">Plea Bargain</div>
                          </div>
                      </div>
                
                      <div className="case-item">
                          <div className="case-year">2021</div>
                          <div className="case-details">
                              <h3>Economic Offences Wing vs. Startup Founder</h3>
                              <p>Defended tech entrepreneur in investor fraud allegations. Established important precedents for startup liability and investor relations.</p>
                              <div className="case-stats">
                                  <span className="stat">Duration: 15 months</span>
                                  <span className="stat">Court: Karnataka High Court</span>
                              </div>
                              <div className="case-outcome victory">Complete Acquittal</div>
                          </div>
                      </div>
                  </div>
              </div>
          </section>

          <section className="philosophy-section illuminated-border">
              <div className="container">
                  <div className="section-header">
                      <div className="drop-cap">D</div>
                      <h2 className="section-title">
                          <span className="sanskrit-text">रक्षा दर्शन</span>
                          <span className="english-text">Defense Philosophy</span>
                      </h2>
                  </div>
            
                  <div className="philosophy-content">
                      <div className="philosophy-quote scroll-highlight" data-highlight="true">
                          <blockquote>
                              "यत्र न्यायो निर्भयेन सत्यमेव जयते"<br />
                              <em>"Where justice is fearless, truth alone triumphs"</em>
                          </blockquote>
                      </div>
                
                      <div className="principles-grid">
                          <div className="principle-item">
                              <h4>Presumption of Innocence</h4>
                              <p>Every individual deserves vigorous defense until proven guilty beyond reasonable doubt</p>
                          </div>
                    
                          <div className="principle-item">
                              <h4>Constitutional Rights</h4>
                              <p>Protecting fundamental rights enshrined in the Constitution against state overreach</p>
                          </div>
                    
                          <div className="principle-item">
                              <h4>Due Process</h4>
                              <p>Ensuring fair trial procedures and challenging procedural violations</p>
                          </div>
                    
                          <div className="principle-item">
                              <h4>Evidence Integrity</h4>
                              <p>Rigorous examination of evidence and investigation procedures</p>
                          </div>
                      </div>
                  </div>
              </div>
          </section>

          <div id="footer-container"></div>
    </div>
  )
}
