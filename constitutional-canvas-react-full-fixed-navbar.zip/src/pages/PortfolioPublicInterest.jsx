import React from 'react';

export default function PortfoilioPublicInterest() {
  return (
    <div className="legacy-page">
      <div id="scroll-progress"></div>
          <div id="navbar-container"></div>
    
          <section className="portfolio-hero illuminated-border">
              <div className="container">
                  <div className="hero-content">
                      <div className="drop-cap">P</div>
                      <h1 className="hero-title">
                          <span className="sanskrit-text">जनहित याचिका</span>
                          <span className="english-text">Public Interest Litigation</span>
                      </h1>
                      <p className="hero-subtitle">Fighting for Social Justice and Constitutional Values</p>
                      <div className="constitution-quote scroll-highlight" data-highlight="true">
                          <blockquote>
                              "न्याय देरी से मिले तो न्याय नहीं, जल्दी मिले तो न्याय नहीं। न्याय सिर्फ सही समय पर मिले तो न्याय।"<br />
                              <em>"Justice delayed is justice denied, justice hurried is justice buried. Justice is only justice when delivered at the right time."</em>
                          </blockquote>
                      </div>
                  </div>
              </div>
          </section>

          <section className="causes-section illuminated-border">
              <div className="container">
                  <div className="section-header">
                      <div className="drop-cap">C</div>
                      <h2 className="section-title">
                          <span className="sanskrit-text">न्याय के क्षेत्र</span>
                          <span className="english-text">Causes We Champion</span>
                      </h2>
                  </div>
            
                  <div className="causes-grid">
                      <div className="cause-card environmental">
                          <div className="cause-icon">🌱</div>
                          <h3>Environmental Protection</h3>
                          <p>Fighting for clean air, water conservation, and sustainable development through judicial intervention</p>
                          <div className="impact-stats">
                              <span className="stat-number">15</span>
                              <span className="stat-label">Active Cases</span>
                          </div>
                      </div>
                
                      <div className="cause-card education">
                          <div className="cause-icon">📚</div>
                          <h3>Right to Education</h3>
                          <p>Ensuring quality education access for underprivileged communities and challenging discriminatory practices</p>
                          <div className="impact-stats">
                              <span className="stat-number">8</span>
                              <span className="stat-label">Landmark Victories</span>
                          </div>
                      </div>
                
                      <div className="cause-card healthcare">
                          <div className="cause-icon">🏥</div>
                          <h3>Healthcare Rights</h3>
                          <p>Advocating for affordable healthcare, medical infrastructure, and patient rights protection</p>
                          <div className="impact-stats">
                              <span className="stat-number">12</span>
                              <span className="stat-label">Policy Changes</span>
                          </div>
                      </div>
                
                      <div className="cause-card governance">
                          <div className="cause-icon">🏛️</div>
                          <h3>Good Governance</h3>
                          <p>Promoting transparency, accountability, and citizen participation in democratic processes</p>
                          <div className="impact-stats">
                              <span className="stat-number">20</span>
                              <span className="stat-label">RTI Applications</span>
                          </div>
                      </div>
                
                      <div className="cause-card rights">
                          <div className="cause-icon">⚡</div>
                          <h3>Fundamental Rights</h3>
                          <p>Protecting constitutional rights of marginalized communities and vulnerable populations</p>
                          <div className="impact-stats">
                              <span className="stat-number">25</span>
                              <span className="stat-label">Rights Upheld</span>
                          </div>
                      </div>
                
                      <div className="cause-card digital">
                          <div className="cause-icon">💻</div>
                          <h3>Digital Rights</h3>
                          <p>Safeguarding privacy, digital freedom, and preventing misuse of technology by authorities</p>
                          <div className="impact-stats">
                              <span className="stat-number">6</span>
                              <span className="stat-label">Precedents Set</span>
                          </div>
                      </div>
                  </div>
              </div>
          </section>

          <section className="landmark-pils illuminated-border">
              <div className="container">
                  <div className="section-header">
                      <div className="drop-cap">L</div>
                      <h2 className="section-title">
                          <span className="sanskrit-text">ऐतिहासिक याचिकाएं</span>
                          <span className="english-text">Landmark PIL Cases</span>
                      </h2>
                  </div>
            
                  <div className="pil-showcase">
                      <div className="pil-case featured">
                          <div className="case-badge">Supreme Court</div>
                          <h3>Clean Air Initiative for Delhi NCR</h3>
                          <div className="case-summary">
                              <p>Comprehensive PIL addressing air pollution crisis in Delhi NCR. Resulted in implementation of odd-even scheme, BS-VI fuel standards, and industrial emission controls.</p>
                          </div>
                          <div className="case-impact">
                              <h4>Impact Achieved:</h4>
                              <ul>
                                  <li>30% reduction in PM2.5 levels during implementation</li>
                                  <li>Mandatory green fuel adoption by public transport</li>
                                  <li>Establishment of real-time air quality monitoring</li>
                                  <li>₹10,000 crore environmental fund allocation</li>
                              </ul>
                          </div>
                          <div className="case-status ongoing">Monitoring Phase</div>
                      </div>
                
                      <div className="pil-case">
                          <div className="case-badge">High Court</div>
                          <h3>Digital Privacy in Government Schools</h3>
                          <div className="case-summary">
                              <p>Challenged mandatory biometric attendance system in government schools without proper data protection safeguards.</p>
                          </div>
                          <div className="case-impact">
                              <h4>Victory Achieved:</h4>
                              <ul>
                                  <li>Data protection guidelines for educational institutions</li>
                                  <li>Parental consent requirements established</li>
                                  <li>Alternative attendance mechanisms implemented</li>
                              </ul>
                          </div>
                          <div className="case-status victory">Victory</div>
                      </div>
                
                      <div className="pil-case">
                          <div className="case-badge">High Court</div>
                          <h3>Healthcare Access in Rural Areas</h3>
                          <div className="case-summary">
                              <p>Systematic PIL addressing inadequate healthcare infrastructure and doctor shortage in rural districts.</p>
                          </div>
                          <div className="case-impact">
                              <h4>Ongoing Progress:</h4>
                              <ul>
                                  <li>500+ new primary health centers sanctioned</li>
                                  <li>Telemedicine connectivity established</li>
                                  <li>Medical college seats increased by 25%</li>
                              </ul>
                          </div>
                          <div className="case-status ongoing">Active Monitoring</div>
                      </div>
                  </div>
              </div>
          </section>

          <section className="social-impact illuminated-border">
              <div className="container">
                  <div className="section-header">
                      <div className="drop-cap">S</div>
                      <h2 className="section-title">
                          <span className="sanskrit-text">सामाजिक प्रभाव</span>
                          <span className="english-text">Social Impact</span>
                      </h2>
                  </div>
            
                  <div className="impact-metrics">
                      <div className="metric-card">
                          <div className="metric-number">2.5M+</div>
                          <div className="metric-label">Lives Impacted</div>
                          <div className="metric-description">Through environmental and healthcare interventions</div>
                      </div>
                
                      <div className="metric-card">
                          <div className="metric-number">50+</div>
                          <div className="metric-label">Policy Changes</div>
                          <div className="metric-description">Government policies reformed through PIL interventions</div>
                      </div>
                
                      <div className="metric-card">
                          <div className="metric-number">₹500Cr+</div>
                          <div className="metric-label">Fund Allocation</div>
                          <div className="metric-description">Government funds redirected to public welfare</div>
                      </div>
                
                      <div className="metric-card">
                          <div className="metric-number">85%</div>
                          <div className="metric-label">Success Rate</div>
                          <div className="metric-description">PIL cases resulting in positive outcomes</div>
                      </div>
                  </div>
            
                  <div className="philosophy-statement scroll-highlight" data-highlight="true">
                      <blockquote>
                          "Public Interest Litigation is not just legal advocacy; it is constitutional patriotism in action. Every PIL filed is a step towards the India envisioned by our Constitution makers—just, equitable, and inclusive."
                      </blockquote>
                      <cite>— Constitutional Canvas Legal Philosophy</cite>
                  </div>
              </div>
          </section>

          <section className="get-involved illuminated-border">
              <div className="container">
                  <div className="section-header">
                      <div className="drop-cap">J</div>
                      <h2 className="section-title">
                          <span className="sanskrit-text">सहयोग करें</span>
                          <span className="english-text">Join the Cause</span>
                      </h2>
                  </div>
            
                  <div className="involvement-options">
                      <div className="involvement-card">
                          <h4>Report Issues</h4>
                          <p>Bring social issues to our attention that require legal intervention</p>
                          <a href="#contact" className="cta-button">Report Now</a>
                      </div>
                
                      <div className="involvement-card">
                          <h4>Pro Bono Support</h4>
                          <p>Legal professionals interested in contributing to public interest causes</p>
                          <a href="#contact" className="cta-button">Volunteer</a>
                      </div>
                
                      <div className="involvement-card">
                          <h4>Research Support</h4>
                          <p>Students and researchers can contribute to PIL case preparation</p>
                          <a href="#contact" className="cta-button">Contribute</a>
                      </div>
                  </div>
              </div>
          </section>

          <div id="footer-container"></div>
    </div>
  )
}
