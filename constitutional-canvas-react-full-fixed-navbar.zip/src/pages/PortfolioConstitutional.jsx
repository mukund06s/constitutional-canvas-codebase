import React from 'react';

export default function PortfolioConstitutional() {
  return (
    <div className="legacy-page">
      <div id="scroll-progress"></div>
          <div id="navbar-container"></div>
    
          <section className="portfolio-hero illuminated-border">
              <div className="container">
                  <div className="hero-content">
                      <div className="drop-cap">C</div>
                      <h1 className="hero-title">
                          <span className="sanskrit-text">संविधान विधि</span>
                          <span className="english-text">Constitutional Law</span>
                      </h1>
                      <p className="hero-subtitle">Guardians of Fundamental Rights and Constitutional Principles</p>
                  </div>
              </div>
          </section>

          <section className="case-studies illuminated-border">
              <div className="container">
                  <div className="section-header">
                      <div className="drop-cap">L</div>
                      <h2 className="section-title">
                          <span className="sanskrit-text">प्रमुख मामले</span>
                          <span className="english-text">Landmark Cases</span>
                      </h2>
                  </div>
            
                  <div className="case-timeline">
                      <div className="case-item">
                          <div className="case-year">2024</div>
                          <div className="case-details">
                              <h3>Right to Privacy vs. National Security</h3>
                              <p>Successfully argued for balancing individual privacy rights with national security imperatives before the Supreme Court.</p>
                              <div className="case-outcome victory">Victory</div>
                          </div>
                      </div>
                
                      <div className="case-item">
                          <div className="case-year">2023</div>
                          <div className="case-details">
                              <h3>Environmental Protection Under Article 21</h3>
                              <p>Expanded the interpretation of "Right to Life" to include environmental protection in industrial zones.</p>
                              <div className="case-outcome victory">Victory</div>
                          </div>
                      </div>
                
                      <div className="case-item">
                          <div className="case-year">2022</div>
                          <div className="case-details">
                              <h3>Digital Rights and Freedom of Expression</h3>
                              <p>Landmark case establishing digital rights as fundamental rights under Article 19.</p>
                              <div className="case-outcome victory">Victory</div>
                          </div>
                      </div>
                  </div>
              </div>
          </section>

          <div id="footer-container"></div>
    </div>
  )
}
