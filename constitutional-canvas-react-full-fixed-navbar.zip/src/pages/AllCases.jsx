import React from 'react';

export default function AllCases() {
  return (
    <div className="legacy-page">
      <div id="scroll-progress"></div>
          <div id="navbar-container"></div>
    
          <section className="portfolio-hero illuminated-border">
              <div className="container">
                  <div className="hero-content">
                      <div className="drop-cap">A</div>
                      <h1 className="hero-title">
                          <span className="sanskrit-text">सभी मामले</span>
                          <span className="english-text">Case Directory</span>
                      </h1>
                      <p className="hero-subtitle">Comprehensive Overview of Our Legal Practice</p>
                      <div className="hero-nav">
                          <a href="/index" className="breadcrumb">Home</a>
                          <span className="breadcrumb-sep">›</span>
                          <span className="breadcrumb current">All Cases</span>
                      </div>
                  </div>
              </div>
          </section>

          <section className="case-filter illuminated-border">
              <div className="container">
                  <div className="filter-controls">
                      <button className="filter-btn active" data-filter="all">All Cases</button>
                      <button className="filter-btn" data-filter="constitutional">Constitutional Law</button>
                      <button className="filter-btn" data-filter="criminal">Criminal Defense</button>
                      <button className="filter-btn" data-filter="civil">Civil Litigation</button>
                      <button className="filter-btn" data-filter="corporate">Corporate Law</button>
                      <button className="filter-btn" data-filter="public-interest">Public Interest</button>
                  </div>
            
                  <div className="cases-directory">
                      <div className="case-card" data-category="constitutional">
                          <div className="case-header">
                              <h3>Right to Privacy vs. National Security</h3>
                              <span className="case-type">Constitutional Law</span>
                          </div>
                          <p>Successfully argued for balancing individual privacy rights with national security imperatives before the Supreme Court.</p>
                          <div className="case-meta">
                              <span className="court">Supreme Court</span>
                              <span className="year">2024</span>
                              <span className="status victory">Victory</span>
                          </div>
                          <a href="/portfolio-constitutional" className="case-link">View Details</a>
                      </div>
                
                      {/* More case cards would be added here */}
                  </div>
              </div>
          </section>

          <div id="footer-container"></div>
    </div>
  )
}
