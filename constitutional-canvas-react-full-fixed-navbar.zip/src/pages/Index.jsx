import React from 'react';

export default function Index() {
  return (
    <div className="legacy-page">
      <div id="scroll-progress"></div>
    
          {/* Include Navbar */}
          <div id="navbar-container"></div>
    
          {/* Hero Section */}
          <section id="home" className="hero-section illuminated-border">
              <div className="manuscript-bg"></div>
              <div className="container">
                  <div className="hero-content">
                      <div className="drop-cap">W</div>
                      <h1 className="hero-title">
                          <span className="sanskrit-text">न्यायाधीश</span>
                          <span className="english-text">Constitutional Canvas</span>
                      </h1>
                      <p className="hero-subtitle">Illuminating Justice Through Legal Excellence</p>
                      <div className="constitution-quote">
                          <blockquote className="scroll-highlight" data-highlight="true">
                              "WE, THE PEOPLE OF INDIA, having solemnly resolved to constitute India into a 
                              <span className="highlight-word">SOVEREIGN</span> <span className="highlight-word">SOCIALIST</span> 
                              <span className="highlight-word">SECULAR</span> <span className="highlight-word">DEMOCRATIC</span> 
                              <span className="highlight-word">REPUBLIC</span>"
                          </blockquote>
                      </div>
                      <div className="hero-cta">
                          <a href="#about" className="cta-primary">Learn More</a>
                          <a href="#contact" className="cta-secondary">Consultation</a>
                      </div>
                  </div>
              </div>
          </section>

          {/* About Section */}
          <section id="about" className="about-section illuminated-border">
              <div className="container">
                  <div className="section-header">
                      <div className="drop-cap">A</div>
                      <h2 className="section-title">
                          <span className="sanskrit-text">परिचय</span>
                          <span className="english-text">About Our Practice</span>
                      </h2>
                  </div>
                  <div className="about-content">
                      <div className="about-text scroll-highlight" data-highlight="true">
                          <p>Established on the foundational principles of justice and equality, our practice 
                          embodies the very essence of constitutional law. Like the illuminated manuscripts 
                          of ancient legal traditions, we bring clarity to complex legal matters through 
                          dedication, expertise, and unwavering commitment to justice.</p>
                    
                          <div className="stats-grid">
                              <div className="stat-item">
                                  <div className="stat-number">25+</div>
                                  <div className="stat-label">Years Experience</div>
                              </div>
                              <div className="stat-item">
                                  <div className="stat-number">500+</div>
                                  <div className="stat-label">Cases Won</div>
                              </div>
                              <div className="stat-item">
                                  <div className="stat-number">95%</div>
                                  <div className="stat-label">Success Rate</div>
                              </div>
                              <div className="stat-item">
                                  <div className="stat-number">50+</div>
                                  <div className="stat-label">PIL Cases</div>
                              </div>
                          </div>
                      </div>
                      <div className="seal-container">
                          <div className="legal-seal">
                              <div className="seal-inner">⚖️</div>
                          </div>
                      </div>
                  </div>
              </div>
          </section>

          {/* Practice Areas */}
          <section id="practice" className="practice-areas illuminated-border">
              <div className="container">
                  <div className="section-header">
                      <div className="drop-cap">P</div>
                      <h2 className="section-title">
                          <span className="sanskrit-text">विधि क्षेत्र</span>
                          <span className="english-text">Practice Areas</span>
                      </h2>
                  </div>
                  <div className="practice-grid">
                      <div className="practice-card" data-area="constitutional">
                          <div className="card-header">
                              <h3>Constitutional Law</h3>
                              <div className="stamp-seal">🏛️</div>
                          </div>
                          <p>Fundamental rights, judicial review, and constitutional interpretation</p>
                          <a href="/portfolio-constitutional" className="card-link">View Cases</a>
                      </div>
                      <div className="practice-card" data-area="criminal">
                          <div className="card-header">
                              <h3>Criminal Defense</h3>
                              <div className="stamp-seal">⚖️</div>
                          </div>
                          <p>Comprehensive criminal defense with emphasis on due process</p>
                          <a href="/portfolio-criminal" className="card-link">View Cases</a>
                      </div>
                      <div className="practice-card" data-area="civil">
                          <div className="card-header">
                              <h3>Civil Litigation</h3>
                              <div className="stamp-seal">📜</div>
                          </div>
                          <p>Complex civil matters and dispute resolution</p>
                          <a href="/portfolio-civil" className="card-link">View Cases</a>
                      </div>
                      <div className="practice-card" data-area="corporate">
                          <div className="card-header">
                              <h3>Corporate Law</h3>
                              <div className="stamp-seal">🏢</div>
                          </div>
                          <p>Business law, compliance, and corporate governance</p>
                          <a href="/portfolio-corporate" className="card-link">View Cases</a>
                      </div>
                      <div className="practice-card featured" data-area="public-interest">
                          <div className="card-header">
                              <h3>Public Interest Litigation</h3>
                              <div className="stamp-seal">🌟</div>
                          </div>
                          <p>Fighting for social justice and constitutional values</p>
                          <a href="/portfolio-public-interest" className="card-link">View Cases</a>
                      </div>
                  </div>
              </div>
          </section>

          {/* Recent Cases Showcase */}
          <section id="portfolio" className="portfolio-section illuminated-border">
              <div className="container">
                  <div className="section-header">
                      <div className="drop-cap">R</div>
                      <h2 className="section-title">
                          <span className="sanskrit-text">हाल के मामले</span>
                          <span className="english-text">Recent Landmark Cases</span>
                      </h2>
                  </div>
                  <div className="portfolio-grid">
                      <div className="portfolio-item featured">
                          <div className="case-category">Constitutional Law</div>
                          <div className="case-number">Case I</div>
                          <h3>Landmark Constitutional Challenge</h3>
                          <p>Successfully defended fundamental rights in Supreme Court</p>
                          <div className="case-outcome victory">Victory</div>
                          <a href="/portfolio-constitutional" className="case-details-link">Read Full Case</a>
                      </div>
                      <div className="portfolio-item">
                          <div className="case-category">Corporate Law</div>
                          <div className="case-number">Case II</div>
                          <h3>Corporate Governance Reform</h3>
                          <p>Led comprehensive compliance restructuring</p>
                          <div className="case-outcome settled">Settled</div>
                          <a href="/portfolio-corporate" className="case-details-link">Read Full Case</a>
                      </div>
                      <div className="portfolio-item">
                          <div className="case-category">Public Interest</div>
                          <div className="case-number">Case III</div>
                          <h3>Environmental Protection PIL</h3>
                          <p>Environmental protection and public welfare</p>
                          <div className="case-outcome ongoing">Ongoing</div>
                          <a href="/portfolio-public-interest" className="case-details-link">Read Full Case</a>
                      </div>
                  </div>
                  <div className="portfolio-cta">
                      <a href="/all-cases" className="view-all-btn">View All Cases</a>
                  </div>
              </div>
          </section>

          {/* Contact Section */}
          <section id="contact" className="contact-section illuminated-border">
              <div className="container">
                  <div className="section-header">
                      <div className="drop-cap">C</div>
                      <h2 className="section-title">
                          <span className="sanskrit-text">संपर्क</span>
                          <span className="english-text">Contact Us</span>
                      </h2>
                  </div>
                  <div className="contact-content">
                      <div className="contact-info">
                          <div className="info-item">
                              <h4>Chambers</h4>
                              <p>Supreme Court Bar Association<br />
                              New Delhi - 110001</p>
                          </div>
                          <div className="info-item">
                              <h4>Consultation</h4>
                              <p>By Appointment Only<br />
                              +91 9876543210</p>
                          </div>
                          <div className="info-item">
                              <h4>Email</h4>
                              <p>chambers@constitutionalcanvas.in<br />
                              info@constitutionalcanvas.in</p>
                          </div>
                      </div>
                      <div className="contact-form">
                          <form className="consultation-form">
                              <h4>Request Consultation</h4>
                              <input type="text" placeholder="Full Name" required />
                              <input type="email" placeholder="Email Address" required />
                              <input type="tel" placeholder="Phone Number" required />
                              <select required>
                                  <option value="">Select Practice Area</option>
                                  <option value="constitutional">Constitutional Law</option>
                                  <option value="criminal">Criminal Defense</option>
                                  <option value="civil">Civil Litigation</option>
                                  <option value="corporate">Corporate Law</option>
                                  <option value="public-interest">Public Interest</option>
                              </select>
                              <textarea placeholder="Brief Description of Your Case" required></textarea>
                              <button type="submit" className="submit-btn">Request Consultation</button>
                          </form>
                      </div>
                  </div>
              </div>
          </section>

          {/* Include Footer */}
          <div id="footer-container"></div>
    </div>
  )
}
