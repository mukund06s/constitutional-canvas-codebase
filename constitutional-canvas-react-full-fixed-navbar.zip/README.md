# constitutional-canvas (Converted to React + Vite + Tailwind)

Auto-converted on 2025-08-14T14:21:18.051583 from your static site.

## Run locally
```bash
npm install
npm run dev
```

## Notes
- Legacy assets were placed in **/public** and are referenced from `index.html`.
- Each HTML file is now a React component in **/src/pages**.
- Routes: `index.html` → `/`, `about.html` → `/about`, etc.
- Internal `.html` links inside pages were rewritten to React paths.
