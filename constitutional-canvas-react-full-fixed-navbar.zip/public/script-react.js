document.addEventListener('DOMContentLoaded', () => {
  // Scroll progress
  let bar = document.getElementById('scroll-progress');
  if (!bar) {
    bar = document.createElement('div');
    bar.id = 'scroll-progress';
    document.body.appendChild(bar);
  }
  const updateBar = () => {
    const total = document.documentElement.scrollHeight - window.innerHeight;
    const p = total > 0 ? (window.scrollY / total) * 100 : 0;
    bar.style.width = p + '%';
  };
  updateBar();
  window.addEventListener('scroll', updateBar, {passive:true});
  window.addEventListener('resize', updateBar);

  // Reveal on intersect
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => e.isIntersecting && e.target.classList.add('in-view'));
  }, { threshold: 0.15 });
  document.querySelectorAll('.fade-in,.slide-in-left,.slide-in-right,.rise-up,.practice-card,.portfolio-item').forEach(el => io.observe(el));

  // Gentle pulse for highlighted words
  const words = [...document.querySelectorAll('.highlight-word')];
  let i = 0;
  setInterval(() => {
    words.forEach((w,idx) => {
      w.style.transition = 'transform .25s ease';
      w.style.transform = idx === i ? 'scale(1.06)' : 'scale(1)';
    });
    i = words.length ? (i+1) % words.length : 0;
  }, 500);

  // Navbar compact on scroll
  const nav = document.querySelector('.navbar');
  if (nav) {
    let lastY = 0;
    window.addEventListener('scroll', () => {
      const y = window.scrollY;
      if (y > 60 && y > lastY) nav.classList.add('nav-compact');
      else if (y < 40) nav.classList.remove('nav-compact');
      lastY = y;
    }, {passive:true});
  }

  // Dropdown hover (desktop)
  document.querySelectorAll('.navbar .dropdown').forEach(dd => {
    const menu = dd.querySelector('.dropdown-menu');
    if (!menu) return;
    dd.addEventListener('mouseenter', () => menu.classList.add('open'));
    dd.addEventListener('mouseleave', () => menu.classList.remove('open'));
  });

  // Mobile toggle
  const toggle = document.getElementById('nav-mobile-toggle');
  const menu = document.querySelector('.navbar .nav-menu');
  if (toggle && menu) {
    toggle.addEventListener('click', () => {
      menu.classList.toggle('open');
      toggle.classList.toggle('active');
    });
  }

  // Smooth scroll for in-page anchors
  document.addEventListener('click', (e) => {
    const a = e.target.closest('a[href^="#"]');
    if (!a) return;
    const id = a.getAttribute('href').slice(1);
    const el = document.getElementById(id);
    if (el) {
      e.preventDefault();
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});
