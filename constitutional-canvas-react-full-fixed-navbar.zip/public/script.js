// Constitutional Canvas - Legal Portfolio JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Load navbar and footer
    loadComponent('navbar-container', 'navbar.html');
    loadComponent('footer-container', 'footer.html');
    
    // Initialize all features
    initScrollProgress();
    initScrollHighlighting();
    initStampSealAnimations();
    initNavbarAnimations();
    initIntersectionObserver();
    initConstitutionWordHighlight();
    initSmoothScrolling();
    initContactForm();
});

// Component Loader with error handling
function loadComponent(containerId, filename) {
    fetch(filename)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.text();
        })
        .then(data => {
            const container = document.getElementById(containerId);
            if (container) {
                container.innerHTML = data;
                if (filename === 'navbar.html') {
                    initNavbarAnimations();
                    initMobileNavigation();
                }
            }
        })
        .catch(error => {
            console.log('Error loading component:', error);
            // Fallback content
            if (containerId === 'navbar-container') {
                document.getElementById(containerId).innerHTML = `
                    <nav class="navbar">
                        <div class="nav-content">
                            <a href="index.html" class="logo">Constitutional Canvas</a>
                            <ul class="nav-menu">
                                <li><a href="index.html#home">Home</a></li>
                                <li><a href="index.html#about">About</a></li>
                                <li><a href="index.html#practice">Practice Areas</a></li>
                                <li><a href="index.html#contact">Contact</a></li>
                            </ul>
                        </div>
                    </nav>
                `;
            }
        });
}

// Initialize smooth scrolling for anchor links
function initSmoothScrolling() {
    document.addEventListener('click', function(e) {
        const link = e.target.closest('a');
        if (link && link.getAttribute('href')) {
            const href = link.getAttribute('href');
            
            // Handle hash links
            if (href.includes('#')) {
                const [page, hash] = href.split('#');
                
                // Same page navigation
                if (!page || page === window.location.pathname || page === 'index.html') {
                    e.preventDefault();
                    const targetElement = document.getElementById(hash);
                    if (targetElement) {
                        targetElement.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                        
                        // Update URL
                        history.pushState(null, null, `#${hash}`);
                    }
                }
            }
        }
    });
    
    // Handle initial page load with hash
    if (window.location.hash) {
        setTimeout(() => {
            const targetElement = document.getElementById(window.location.hash.substring(1));
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        }, 100);
    }
}

// Initialize mobile navigation
function initMobileNavigation() {
    const mobileToggle = document.querySelector('.nav-mobile-toggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (mobileToggle && navMenu) {
        mobileToggle.addEventListener('click', function() {
            navMenu.classList.toggle('active');
            this.classList.toggle('active');
        });
        
        // Close mobile menu when clicking outside
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.navbar')) {
                navMenu.classList.remove('active');
                mobileToggle.classList.remove('active');
            }
        });
    }
}

// Initialize contact form
function initContactForm() {
    const form = document.querySelector('.consultation-form');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data
            const formData = new FormData(this);
            const data = Object.fromEntries(formData);
            
            // Simple validation
            if (!data.name || !data.email || !data.phone || !data.practice_area || !data.message) {
                alert('Please fill in all required fields.');
                return;
            }
            
            // Simulate form submission
            const submitBtn = this.querySelector('.submit-btn');
            const originalText = submitBtn.textContent;
            
            submitBtn.textContent = 'Sending...';
            submitBtn.disabled = true;
            
            setTimeout(() => {
                alert('Thank you for your consultation request. We will contact you within 24 hours.');
                this.reset();
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
            }, 2000);
        });
    }
}

// Rest of the existing JavaScript functions remain the same...
// (keeping all the existing functions from the previous script.js)

// Scroll Progress Bar
function initScrollProgress() {
    const progressBar = document.getElementById('scroll-progress');
    if (progressBar) {
        window.addEventListener('scroll', () => {
            const windowHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
            const scrolled = (window.scrollY / windowHeight) * 100;
            progressBar.style.width = scrolled + '%';
        });
    }
}

// Constitution Word Highlighting
function initConstitutionWordHighlight() {
    const highlightWords = document.querySelectorAll('.highlight-word');
    
    highlightWords.forEach((word, index) => {
        setTimeout(() => {
            word.addEventListener('mouseenter', () => {
                word.classList.add('active');
                createStampEffect(word);
            });
            
            word.addEventListener('mouseleave', () => {
                word.classList.remove('active');
            });
            
            // Auto-highlight words in sequence on first load
            setTimeout(() => {
                word.classList.add('active');
                setTimeout(() => {
                    word.classList.remove('active');
                }, 800);
            }, index * 200);
        }, 1000);
    });
}

// Create stamp effect
function createStampEffect(element) {
    const stamp = document.createElement('div');
    stamp.innerHTML = '⚖️';
    stamp.style.cssText = `
        position: absolute;
        font-size: 1.5rem;
        pointer-events: none;
        z-index: 1000;
        animation: stampFade 1s ease-out forwards;
        color: #8b0000;
    `;
    
    const rect = element.getBoundingClientRect();
    stamp.style.left = (rect.left + rect.width/2) + 'px';
    stamp.style.top = (rect.top - 30) + 'px';
    
    document.body.appendChild(stamp);
    
    // Add stamp animation keyframes if not exists
    if (!document.getElementById('stamp-animation-style')) {
        const style = document.createElement('style');
        style.id = 'stamp-animation-style';
        style.textContent = `
            @keyframes stampFade {
                0% { transform: scale(0) rotate(0deg); opacity: 1; }
                50% { transform: scale(1.2) rotate(180deg); opacity: 0.8; }
                100% { transform: scale(0.8) rotate(360deg); opacity: 0; }
            }
        `;
        document.head.appendChild(style);
    }
    
    setTimeout(() => {
        if (stamp.parentNode) {
            document.body.removeChild(stamp);
        }
    }, 1000);
}

// Scroll-triggered highlighting
function initScrollHighlighting() {
    const highlightElements = document.querySelectorAll('.scroll-highlight');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('highlighted');
                
                // Trigger word-by-word highlighting for constitution quotes
                if (entry.target.dataset.highlight === 'true') {
                    highlightWordsSequentially(entry.target);
                }
            }
        });
    }, {
        threshold: 0.5,
        rootMargin: '0px 0px -100px 0px'
    });
    
    highlightElements.forEach(el => observer.observe(el));
}

// Highlight words sequentially
function highlightWordsSequentially(element) {
    const words = element.textContent.split(' ');
    element.innerHTML = words.map(word => `<span class="word-highlight">${word}</span>`).join(' ');
    
    const wordSpans = element.querySelectorAll('.word-highlight');
    
    wordSpans.forEach((span, index) => {
        setTimeout(() => {
            span.style.cssText = `
                background: linear-gradient(120deg, #d4af37, #ffd700);
                color: #2c1810;
                padding: 0 0.2rem;
                border-radius: 3px;
                transition: all 0.3s ease;
                display: inline-block;
                transform: scale(1.05);
            `;
            
            setTimeout(() => {
                span.style.transform = 'scale(1)';
            }, 300);
        }, index * 100);
    });
}

// Stamp seal animations for practice areas
function initStampSealAnimations() {
    const practiceCards = document.querySelectorAll('.practice-card');
    
    practiceCards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            const seal = card.querySelector('.stamp-seal');
            if (seal) {
                // Create ink splatter effect
                createInkSplatter(seal);
                
                // Add rotational momentum
                seal.style.animation = 'sealRotate 0.6s ease-out';
            }
        });
        
        card.addEventListener('mouseleave', () => {
            const seal = card.querySelector('.stamp-seal');
            if (seal) {
                seal.style.animation = '';
            }
        });
    });
    
    // Add seal rotation keyframes
    if (!document.getElementById('seal-animation-style')) {
        const style = document.createElement('style');
        style.id = 'seal-animation-style';
        style.textContent = `
            @keyframes sealRotate {
                0% { transform: rotate(0deg) scale(1); }
                50% { transform: rotate(180deg) scale(1.1); }
                100% { transform: rotate(360deg) scale(1.1); }
            }
            
            @keyframes inkSplatter {
                0% { transform: scale(0); opacity: 1; }
                50% { transform: scale(1.5); opacity: 0.7; }
                100% { transform: scale(2); opacity: 0; }
            }
        `;
        document.head.appendChild(style);
    }
}

// Create ink splatter effect
function createInkSplatter(seal) {
    const splatter = document.createElement('div');
    splatter.style.cssText = `
        position: absolute;
        width: 20px;
        height: 20px;
        background: radial-gradient(circle, #8b0000, transparent);
        border-radius: 50%;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        pointer-events: none;
        animation: inkSplatter 0.8s ease-out forwards;
        z-index: -1;
    `;
    
    seal.appendChild(splatter);
    
    setTimeout(() => {
        if (splatter.parentNode) {
            splatter.parentNode.removeChild(splatter);
        }
    }, 800);
}

// Navbar tab animations
function initNavbarAnimations() {
    const navItems = document.querySelectorAll('.nav-item');
    
    navItems.forEach((item, index) => {
        // Animate items like index tabs
        item.style.animationDelay = `${index * 0.1}s`;
        item.classList.add('tab-slide-in');
    });
    
    // Add tab slide-in animation
    if (!document.getElementById('tab-animation-style')) {
        const style = document.createElement('style');
        style.id = 'tab-animation-style';
        style.textContent = `
            .tab-slide-in {
                animation: tabSlideIn 0.6s ease-out forwards;
                opacity: 0;
                transform: translateY(-20px);
            }
            
            @keyframes tabSlideIn {
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
        `;
        document.head.appendChild(style);
    }
}

// Intersection Observer for fade-in animations
function initIntersectionObserver() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, observerOptions);
    
    // Add animation classes to elements
    document.querySelectorAll('.section-header').forEach(el => {
        el.classList.add('fade-in');
        observer.observe(el);
    });
    
    document.querySelectorAll('.practice-card').forEach((el, index) => {
        el.classList.add(index % 2 === 0 ? 'slide-in-left' : 'slide-in-right');
        observer.observe(el);
    });
    
    document.querySelectorAll('.portfolio-item').forEach(el => {
        el.classList.add('fade-in');
        observer.observe(el);
    });
}
